package fitnessTracker;

public class DurationException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public DurationException( )
    {
        super();
    }

    public DurationException( String message )
    {
        super(message);
    }

}

