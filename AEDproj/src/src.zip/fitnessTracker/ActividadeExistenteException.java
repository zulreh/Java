package fitnessTracker;

public class ActividadeExistenteException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public ActividadeExistenteException( )
    {
        super();
    }

    public ActividadeExistenteException( String message )
    {
        super(message);
    }

}

