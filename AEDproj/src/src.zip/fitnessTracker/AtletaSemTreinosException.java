package fitnessTracker;

public class AtletaSemTreinosException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public AtletaSemTreinosException( )
    {
        super();
    }

    public AtletaSemTreinosException( String message )
    {
        super(message);
    }

}

