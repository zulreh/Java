package fitnessTracker;

public class METException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public METException( )
    {
        super();
    }

    public METException( String message )
    {
        super(message);
    }

}

