package fitnessTracker;

public class GrupoExistenteException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public GrupoExistenteException( )
    {
        super();
    }

    public GrupoExistenteException( String message )
    {
        super(message);
    }

}

