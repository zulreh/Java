package fitnessTracker;

public class AtletaComGrupoException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public AtletaComGrupoException( )
    {
        super();
    }

    public AtletaComGrupoException( String message )
    {
        super(message);
    }

}

