package fitnessTracker;

public class AtletaNaoPertenceGrupoException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public AtletaNaoPertenceGrupoException( )
    {
        super();
    }

    public AtletaNaoPertenceGrupoException( String message )
    {
        super(message);
    }

}

