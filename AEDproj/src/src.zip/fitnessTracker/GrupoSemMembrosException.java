package fitnessTracker;

public class GrupoSemMembrosException extends RuntimeException{


    static final long serialVersionUID = 0L;


    public GrupoSemMembrosException( )
    {
        super();
    }

    public GrupoSemMembrosException( String message )
    {
        super(message);
    }

}

